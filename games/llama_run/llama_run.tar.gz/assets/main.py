# FREE YOUR MIND — Walter's Cave Run
# Setup: Install pygame-ce with `python3 -m pip install pygame-ce`
# Run: python3 main.py   (or drag main.py into Terminal after typing python3)
# Main character uses llama.png (save it in the same folder as this file).
# The rest of the graphics are generated with pygame; ugh.ogg is optional.
# This version is also pygbag-compatible (async loop) so it can run in a web browser.

import asyncio   # needed so the game can also run in a web browser
import os
import math
import random
import sys
import array
import pygame

BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # folder this file lives in (for future sprite/sound files)

pygame.init()

# Audio is optional on machines (or browsers) without a sound device.
AUDIO_OK = False
try:
    pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
    AUDIO_OK = True
except Exception:
    pass

WIDTH, HEIGHT = 800, 500
FPS = 60
WORLD_WIDTH = 3500
GROUND_Y = 445
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("FREE YOUR MIND - Walter's Cave Run")
clock = pygame.time.Clock()


# ---- Main character sprite sheet ----
# llama.png must be saved in the same folder as this file.
# It is one row of 6 frames, each 48 x 48 pixels (288 x 48 in total).
SPRITE_FILE = "llama.png"
FRAME_W, FRAME_H = 48, 48
FRAME_COUNT = 6
SPRITE_FACES_RIGHT = True   # change to False if your llama looks backwards when walking
FRAMES_RIGHT = []
FRAMES_LEFT = []
try:
    _sheet = pygame.image.load(os.path.join(BASE_DIR, "llama.png")).convert_alpha()
    for _i in range(FRAME_COUNT):
        _frame = _sheet.subsurface(pygame.Rect(_i * FRAME_W, 0, FRAME_W, FRAME_H)).copy()
        _flipped = pygame.transform.flip(_frame, True, False)
        if SPRITE_FACES_RIGHT:
            FRAMES_RIGHT.append(_frame)
            FRAMES_LEFT.append(_flipped)
        else:
            FRAMES_RIGHT.append(_flipped)
            FRAMES_LEFT.append(_frame)
except Exception:
    print("Could not load llama.png - put it in the same folder as main.py. Using the drawn character instead.")
    FRAMES_RIGHT = []
    FRAMES_LEFT = []

FONT = pygame.font.Font(None, 30)
BIG_FONT = pygame.font.Font(None, 68)
SMALL_FONT = pygame.font.Font(None, 22)

# Palette
BLACK = (12, 15, 14)
STONE = (48, 57, 53)
STONE_LIGHT = (75, 82, 73)
MOSS = (57, 99, 55)
MOSS_LIGHT = (91, 133, 64)
WOOD = (119, 72, 37)
WOOD_LIGHT = (165, 105, 52)
RED = (196, 43, 48)
WHITE = (238, 235, 218)


def make_ugh_sound():
    # Builds the original short "ugh" tone as a fallback. Audio failure stays non-fatal.
    if not AUDIO_OK:
        return None
    try:
        sample_rate = 22050
        duration = 0.20
        samples = array.array("h")
        for i in range(int(sample_rate * duration)):
            t = i / sample_rate
            envelope = max(0.0, 1.0 - t / duration)
            freq = 230 - 100 * (t / duration)
            value = math.sin(2 * math.pi * freq * t) + 0.35 * math.sin(2 * math.pi * freq * 2.1 * t)
            samples.append(int(max(-1, min(1, value * envelope * 7000))))
        return pygame.mixer.Sound(buffer=samples.tobytes())
    except Exception:
        return None


PLACEHOLDER_UGH_SOUND = make_ugh_sound()
UGH_SOUND = PLACEHOLDER_UGH_SOUND
UGH_IS_EXTERNAL = False
if AUDIO_OK:
    try:
        UGH_SOUND = pygame.mixer.Sound(os.path.join(BASE_DIR, "ugh.ogg"))
        UGH_IS_EXTERNAL = True
    except Exception as error:
        print("Could not load ugh.ogg (" + str(error) + "). Using the placeholder Ugh sound instead.")
        UGH_SOUND = PLACEHOLDER_UGH_SOUND


def play_ugh_sound():
    # If the teacher-provided sound cannot play, report it and try the original tone.
    global UGH_SOUND, UGH_IS_EXTERNAL
    if UGH_SOUND is None:
        return
    try:
        UGH_SOUND.play()
    except Exception as error:
        if UGH_IS_EXTERNAL:
            print("Could not play ugh.ogg (" + str(error) + "). Using the placeholder Ugh sound instead.")
            UGH_SOUND = PLACEHOLDER_UGH_SOUND
            UGH_IS_EXTERNAL = False
            if UGH_SOUND is not None:
                try:
                    UGH_SOUND.play()
                except Exception as fallback_error:
                    print("Could not play the placeholder Ugh sound either: " + str(fallback_error))
        else:
            print("Could not play the placeholder Ugh sound: " + str(error))


class Player:
    # The collision box remains compact; the detailed sprite is drawn around it.
    WIDTH = 30
    HEIGHT = 42

    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, self.WIDTH, self.HEIGHT)
        self.vx = 0.0
        self.vy = 0.0
        self.on_ground = False
        self.invulnerable = 0
        self.facing = 1
        self.grabbing = False
        self.grab_side = 0
        self.anim_frame = 0

    def draw(self, surf, camera_x):
        # Approximately 48 by 56 pixels, centered over the collision box.
        cx = int(self.rect.centerx - camera_x)
        base_y = self.rect.bottom
        if self.invulnerable > 0 and (self.invulnerable // 5) % 2 == 0:
            return
        if self.grabbing:
            pose = "climb"
            bob = 0
        elif not self.on_ground:
            pose = "jump"
            bob = 0
        elif abs(self.vx) > 0:
            pose = "walk"
            bob = 1 if self.anim_frame % 12 < 6 else 0
        else:
            pose = "idle"
            bob = int(math.sin(self.anim_frame * 0.11) * 2)
        top = base_y - 56 + bob
        direction = self.facing

        # If the sprite sheet loaded, draw the llama instead of the drawn character.
        if FRAMES_RIGHT:
            if pose == "walk":
                index = (self.anim_frame // 6) % FRAME_COUNT   # cycle through all 6 frames
            else:
                index = 0                                       # standing, jumping, climbing
            image = FRAMES_RIGHT[index] if direction > 0 else FRAMES_LEFT[index]
            surf.blit(image, (cx - FRAME_W // 2, base_y - 45 + bob))
            return

        # Boots and legs: alternate in a walk, tuck in a jump, reach in a climb.
        if pose == "walk":
            phase = (self.anim_frame // 7) % 2
            if phase == 0:
                legs = [(cx - 11, base_y - 17, cx - 7, base_y - 3),
                        (cx + 3, base_y - 17, cx + 12, base_y - 7)]
            else:
                legs = [(cx - 12, base_y - 17, cx - 3, base_y - 7),
                        (cx + 7, base_y - 17, cx + 11, base_y - 3)]
        elif pose == "jump":
            legs = [(cx - 11, base_y - 17, cx - 2, base_y - 9),
                    (cx + 2, base_y - 17, cx + 12, base_y - 10)]
        elif pose == "climb":
            legs = [(cx - 10, base_y - 20, cx - 1, base_y - 10),
                    (cx + 1, base_y - 14, cx + 11, base_y - 4)]
        else:
            legs = [(cx - 10, base_y - 17, cx - 5, base_y - 2),
                    (cx + 4, base_y - 17, cx + 9, base_y - 2)]
        for x1, y1, x2, y2 in legs:
            pygame.draw.line(surf, (35, 29, 27), (x1, y1), (x2, y2), 7)
            pygame.draw.line(surf, (20, 18, 17), (x1 - 2, y2), (x2 + 5, y2), 5)

        # Coat body with a bright front panel and belt.
        torso = pygame.Rect(cx - 17, top + 24, 34, 23)
        pygame.draw.rect(surf, (25, 21, 20), torso.inflate(4, 2))
        pygame.draw.rect(surf, (55, 46, 39), torso)
        pygame.draw.rect(surf, WHITE, (cx - 12, top + 27, 24, 13))
        pygame.draw.rect(surf, (30, 26, 24), (cx - 13, top + 39, 26, 4))
        pygame.draw.rect(surf, (105, 66, 42), (cx - 16, top + 45, 32, 4))
        # Backpack / side strap.
        pygame.draw.rect(surf, (24, 22, 21), (cx - 20 if direction > 0 else cx + 12, top + 28, 8, 17))
        pygame.draw.line(surf, (132, 88, 53), (cx - 10, top + 25), (cx + 9, top + 44), 3)

        # Arms are articulated with simple primitive segments.
        if pose == "climb":
            arm_y = top + 21
            for side, reach in ((-1, -1), (1, 1)):
                shoulder = (cx + side * 12, arm_y)
                elbow = (cx + side * 19, top + 13)
                hand = (cx + side * (22 if direction == side else 18), top + 4)
                pygame.draw.line(surf, (80, 57, 42), shoulder, elbow, 7)
                pygame.draw.line(surf, (227, 181, 137), elbow, hand, 6)
                pygame.draw.circle(surf, (227, 181, 137), hand, 4)
        elif pose == "jump":
            for side in (-1, 1):
                shoulder = (cx + side * 12, top + 30)
                elbow = (cx + side * 19, top + 22)
                hand = (cx + side * 21, top + 15)
                pygame.draw.line(surf, (80, 57, 42), shoulder, elbow, 7)
                pygame.draw.line(surf, (227, 181, 137), elbow, hand, 6)
        else:
            swing = (4 if (self.anim_frame // 7) % 2 == 0 else -4) if pose == "walk" else 0
            for side in (-1, 1):
                shoulder = (cx + side * 12, top + 30)
                hand = (cx + side * 17, top + 38 + (swing if side == direction else -swing))
                pygame.draw.line(surf, (80, 57, 42), shoulder, hand, 7)
                pygame.draw.circle(surf, (227, 181, 137), hand, 4)

        # Head, hair, face, and red cap.
        pygame.draw.rect(surf, (18, 16, 17), (cx - 14, top + 7, 28, 22))
        pygame.draw.rect(surf, (227, 181, 137), (cx - 11, top + 10, 22, 17))
        pygame.draw.rect(surf, (18, 16, 17), (cx - 14, top + 8, 6, 20))
        pygame.draw.rect(surf, (18, 16, 17), (cx - 10, top + 5, 20, 6))
        pygame.draw.rect(surf, RED, (cx - 13, top + 1, 26, 8))
        pygame.draw.rect(surf, RED, (cx - 19, top + 7, 38, 5))
        pygame.draw.rect(surf, (143, 30, 36), (cx - 10, top + 3, 17, 3))
        eye_x = cx + (5 if direction > 0 else -7)
        pygame.draw.rect(surf, BLACK, (eye_x, top + 15, 3, 3))
        pygame.draw.line(surf, (115, 65, 49), (cx + direction * 2, top + 23), (cx + direction * 8, top + 23), 2)


class Spider:
    BODY_RADIUS = 12

    def __init__(self, x, platform_y, left, right):
        self.x = float(x)
        self.y = platform_y - 15
        self.left = left
        self.right = right
        self.speed = random.choice([-1, 1]) * 1.1
        self.alive = True
        self.anim_frame = random.randrange(20)

    def update(self):
        if not self.alive:
            return
        self.anim_frame += 1
        self.x += self.speed
        if self.x < self.left or self.x > self.right:
            self.speed *= -1
            self.x = max(self.left, min(self.x, self.right))

    def rect(self):
        return pygame.Rect(int(self.x - 19), int(self.y - 15), 38, 30)

    def draw(self, surf, camera_x):
        if not self.alive:
            return
        cx, cy = int(self.x - camera_x), int(self.y)
        leg_color = (18, 17, 20)
        # Eight segmented, bent legs with animated outer joints.
        step = int(math.sin(self.anim_frame * 0.25) * 3)
        for side in (-1, 1):
            for index, dy in enumerate((-10, -4, 4, 10)):
                hip = (cx + side * 7, cy + dy // 2)
                knee = (cx + side * (16 + (index % 2) * 2), cy + dy + (step if index % 2 else -step))
                foot = (cx + side * (23 + (index % 2) * 2), cy + dy + (4 if dy > 0 else -4))
                pygame.draw.line(surf, leg_color, hip, knee, 4)
                pygame.draw.line(surf, (52, 43, 45), knee, foot, 3)
                pygame.draw.circle(surf, (31, 28, 31), knee, 2)
        # Rounded head and patterned abdomen.
        pygame.draw.ellipse(surf, (20, 18, 22), (cx - 12, cy - 12, 25, 24))
        pygame.draw.ellipse(surf, (74, 35, 45), (cx - 4, cy - 10, 17, 20))
        pygame.draw.polygon(surf, (133, 59, 55), [(cx + 4, cy - 8), (cx + 12, cy - 5), (cx + 13, cy), (cx + 5, cy - 2)])
        pygame.draw.polygon(surf, (133, 59, 55), [(cx + 4, cy + 2), (cx + 13, cy + 1), (cx + 11, cy + 6), (cx + 3, cy + 8)])
        pygame.draw.line(surf, (174, 99, 77), (cx + 2, cy - 1), (cx + 12, cy - 2), 2)
        pygame.draw.circle(surf, (245, 210, 123), (cx - 6, cy - 4), 2)
        pygame.draw.circle(surf, (245, 210, 123), (cx - 1, cy - 4), 2)
        pygame.draw.circle(surf, BLACK, (cx - 6, cy - 4), 1)
        pygame.draw.circle(surf, BLACK, (cx - 1, cy - 4), 1)


class FallingStalactite:
    def __init__(self, x, tip_y):
        self.x = int(x)
        self.tip_y = int(tip_y)
        self.width = random.randint(10, 22)
        self.height = random.randint(28, 55)
        self.state = "hanging"
        self.y = float(tip_y)
        self.vy = 0.0
        self.reset_timer = 0

    def trigger(self):
        if self.state == "hanging":
            self.state = "falling"
            self.vy = 1.8

    def update(self):
        if self.state == "falling":
            self.vy = min(self.vy + 0.32, 12)
            self.y += self.vy
            # End the active fall at the floor or once the object has left the play area.
            if self.y >= GROUND_Y or self.y > HEIGHT + 70:
                self.state = "waiting"
                self.reset_timer = random.randint(180, 360)
                return True
        elif self.state == "waiting":
            self.reset_timer -= 1
            if self.reset_timer <= 0:
                self.state = "hanging"
                self.y = float(self.tip_y)
        return False

    def collision_rect(self):
        if self.state == "falling":
            return pygame.Rect(self.x - self.width // 2, int(self.y - self.height), self.width, self.height)
        return None

    def draw(self, surf, camera_x):
        if self.state not in ("hanging", "falling"):
            return
        x = int(self.x - camera_x)
        if x < -35 or x > WIDTH + 35:
            return
        tip = int(self.tip_y if self.state == "hanging" else self.y)
        half = self.width // 2
        top = tip - self.height
        left = (x - half, top)
        right = (x + half, top + 2)
        point = (x + random.choice((-1, 0, 1)), tip)
        pygame.draw.polygon(surf, (97, 103, 97), [left, right, point])
        # Faceted rock planes add depth and varied stone color.
        pygame.draw.polygon(surf, (59, 67, 66), [left, (x, top + 3), point])
        pygame.draw.polygon(surf, (121, 127, 116), [(x, top + 3), right, point])
        pygame.draw.polygon(surf, (75, 82, 78), [(x - half // 2, top + self.height // 3), (x, top + self.height // 2), point])
        pygame.draw.line(surf, (151, 155, 143), (x - half + 2, top + 3), (x - 1, tip - 7), 1)
        pygame.draw.line(surf, (43, 49, 49), (x + 2, top + self.height // 2), (x + 1, tip - 3), 1)
        pygame.draw.line(surf, (43, 48, 47), (x - 3, top + self.height // 2), (x - 1, top + self.height // 2 + 5), 1)
        pygame.draw.line(surf, (43, 48, 47), (x + 4, top + self.height // 3), (x + 2, top + self.height // 3 + 4), 1)


PLATFORMS = [
    (0, 445, 410, 55), (300, 390, 170, 22), (520, 345, 170, 22),
    (760, 395, 180, 22), (1010, 340, 180, 22), (1260, 292, 170, 22),
    (1490, 350, 190, 22), (1760, 300, 180, 22), (1990, 355, 180, 22),
    (2220, 305, 190, 22), (2460, 350, 180, 22), (2690, 295, 190, 22),
    (2940, 345, 190, 22), (3190, 395, 310, 55),
    (560, 265, 135, 20), (900, 275, 125, 20), (1600, 245, 130, 20),
    (2340, 225, 130, 20), (2810, 220, 125, 20),
]

MUSHROOMS = [
    (165, 431), (355, 376), (574, 331), (820, 381), (1060, 326),
    (1315, 278), (1545, 336), (1815, 286), (2045, 341), (2285, 291),
    (2520, 336), (2750, 281), (3000, 331), (3270, 381),
    (605, 251), (943, 261), (1640, 231), (2380, 211), (2848, 206),
]


def make_stalactite_layout():
    # At least 30 ceiling hazards, distributed across the entire world.
    xs = list(range(65, WORLD_WIDTH, 105))
    return [FallingStalactite(x, random.randint(58, 130)) for x in xs]


class Game:
    def __init__(self):
        self.state = "title"
        self.reset()
        self.title_time = 0

    def reset(self):
        self.player = Player(65, GROUND_Y - Player.HEIGHT)
        self.lives = 3
        self.score = 0
        self.camera_x = 0
        self.shake = 0
        self.mushrooms = [list(m) + [True] for m in MUSHROOMS]
        self.spiders = [
            Spider(610, 345, 535, 680), Spider(1110, 340, 1030, 1170),
            Spider(1550, 350, 1500, 1660), Spider(2040, 355, 2000, 2150),
            Spider(2750, 295, 2700, 2860), Spider(3310, 395, 3210, 3460),
        ]
        self.stalactites = make_stalactite_layout()
        self.active_stalactite = None
        self.stalactite_delay = random.randint(60, 150)

    def hit_player(self):
        if self.player.invulnerable > 0:
            return
        self.lives -= 1
        self.player.invulnerable = 105
        self.player.vy = -5
        self.player.grabbing = False
        self.shake = 14
        play_ugh_sound()
        if self.lives <= 0:
            self.state = "gameover"

    def update_stalactite_manager(self):
        # The manager owns the sole falling hazard. Other stones can only hang or reset.
        if self.active_stalactite is None:
            self.stalactite_delay -= 1
            if self.stalactite_delay <= 0:
                candidates = [s for s in self.stalactites if s.state == "hanging"]
                if candidates:
                    self.active_stalactite = random.choice(candidates)
                    self.active_stalactite.trigger()
                else:
                    self.stalactite_delay = 60
        for spike in self.stalactites:
            finished = spike.update()
            if spike is self.active_stalactite and finished:
                self.active_stalactite = None
                self.stalactite_delay = random.randint(FPS, FPS * 3)

    def update(self):
        if self.state != "playing":
            return
        keys = pygame.key.get_pressed()
        p = self.player
        p.anim_frame += 1
        old_rect = p.rect.copy()
        old_bottom = old_rect.bottom
        was_grabbing = p.grabbing

        horizontal = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            horizontal -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            horizontal += 1
        if horizontal:
            p.facing = horizontal
        p.vx = horizontal * (2.4 if was_grabbing else 3.4)

        # Wall jump: jump away from the side currently being held.
        if was_grabbing and (keys[pygame.K_SPACE] or keys[pygame.K_w]):
            p.vy = -12.2
            p.vx = -p.grab_side * 5.2
            p.grabbing = False
            p.on_ground = False
        elif not was_grabbing and (keys[pygame.K_SPACE] or keys[pygame.K_w]) and p.on_ground:
            p.vy = -12.2
            p.on_ground = False

        # Move horizontally, then test only actual platforms for a side grab.
        p.rect.x += int(p.vx)
        p.rect.x = max(0, min(WORLD_WIDTH - p.rect.width, p.rect.x))
        p.grabbing = False
        p.grab_side = 0
        if not p.on_ground and p.vy >= 0 and horizontal:
            for px, py, pw, ph in PLATFORMS:
                platform_rect = pygame.Rect(px, py, pw, ph)
                vertical_overlap = p.rect.bottom > py + 2 and p.rect.top < py + ph
                if not vertical_overlap:
                    continue
                if horizontal > 0 and old_rect.right <= px and p.rect.right >= px:
                    p.rect.right = px
                    p.grabbing = True
                    p.grab_side = 1
                    break
                if horizontal < 0 and old_rect.left >= px + pw and p.rect.left <= px + pw:
                    p.rect.left = px + pw
                    p.grabbing = True
                    p.grab_side = -1
                    break
        if p.grabbing:
            p.vx = 0
            p.vy = min(max(p.vy, 1.0), 2.1)

        # Gravity and vertical platform landing. Floor is not considered a climbable wall.
        if not p.grabbing:
            p.vy = min(p.vy + 0.48, 11)
        old_bottom = p.rect.bottom
        p.rect.y += int(p.vy)
        p.on_ground = False
        if p.vy >= 0 and not p.grabbing:
            for px, py, pw, ph in PLATFORMS:
                if p.rect.right > px and p.rect.left < px + pw and old_bottom <= py and p.rect.bottom >= py:
                    p.rect.bottom = py
                    p.vy = 0
                    p.on_ground = True
                    p.grabbing = False
                    break
        if p.rect.bottom >= GROUND_Y:
            p.rect.bottom = GROUND_Y
            p.vy = 0
            p.on_ground = True
            p.grabbing = False

        for mushroom in self.mushrooms:
            mx, my, alive = mushroom
            if alive and p.rect.colliderect(pygame.Rect(mx - 9, my - 15, 18, 15)):
                mushroom[2] = False
                self.score += 10

        for spider in self.spiders:
            spider.update()
            if not spider.alive:
                continue
            spider_box = spider.rect()
            horizontal_overlap = abs(p.rect.centerx - spider.x) <= 25
            stomp_window = -18 <= spider_box.top - p.rect.bottom <= 18
            descending = p.vy > 0 and old_bottom <= spider_box.top + 18
            if horizontal_overlap and stomp_window and descending:
                spider.alive = False
                p.rect.bottom = spider_box.top
                p.vy = -7.0
                p.on_ground = False
                p.grabbing = False
                self.score += 25
            elif p.rect.colliderect(spider_box):
                # A side collision is damaging only when Walter is not descending onto it.
                if not (p.vy > 0 and old_bottom <= spider_box.top + 18):
                    self.hit_player()

        self.update_stalactite_manager()
        for spike in self.stalactites:
            hazard = spike.collision_rect()
            if hazard and p.rect.colliderect(hazard):
                self.hit_player()

        if p.invulnerable > 0:
            p.invulnerable -= 1
        target = p.rect.centerx - WIDTH // 2
        self.camera_x = max(0, min(WORLD_WIDTH - WIDTH, target))
        if self.shake > 0:
            self.shake -= 1
        if p.rect.x >= 3370:
            self.state = "win"

    def draw_background(self, offset_y):
        screen.fill((29, 36, 34))
        for row in range(0, HEIGHT, 70):
            shift = int((self.camera_x * 0.25) % 120)
            for col in range(-120, WIDTH + 120, 120):
                x = col - shift + (35 if (row // 70) % 2 else 0)
                rect = pygame.Rect(x, row + offset_y, 116, 66)
                pygame.draw.rect(screen, (39, 48, 45), rect)
                pygame.draw.line(screen, (54, 63, 57), (rect.x + 8, rect.y + 10), (rect.x + 48, rect.y + 10), 2)
        for i in range(16):
            x = (i * 97 - int(self.camera_x * 0.18)) % (WIDTH + 70) - 30
            y = 82 + (i * 47) % 265
            pygame.draw.ellipse(screen, MOSS, (x, y + offset_y, 36, 10))
            pygame.draw.ellipse(screen, MOSS_LIGHT, (x + 8, y + offset_y - 2, 12, 5))
        pygame.draw.rect(screen, (34, 43, 38), (0, GROUND_Y + offset_y, WIDTH, HEIGHT - GROUND_Y))
        pygame.draw.line(screen, MOSS, (0, GROUND_Y + offset_y), (WIDTH, GROUND_Y + offset_y), 4)

    def draw_platform(self, plat, offset_y):
        x, y, w, h = plat
        sx = int(x - self.camera_x)
        if sx + w < 0 or sx > WIDTH:
            return
        pygame.draw.rect(screen, WOOD, (sx, y + offset_y, w, h))
        pygame.draw.rect(screen, WOOD_LIGHT, (sx, y + offset_y, w, 5))
        for bx in range(sx + 15, sx + w, 42):
            pygame.draw.line(screen, (85, 49, 29), (bx, y + offset_y + 5), (bx, y + offset_y + h - 1), 2)
        pygame.draw.line(screen, (195, 131, 67), (sx + 5, y + offset_y + h - 5), (sx + w - 5, y + offset_y + h - 5), 2)

    def draw_mushroom(self, x, y, offset_y):
        sx = int(x - self.camera_x)
        pygame.draw.rect(screen, WHITE, (sx - 3, y - 12 + offset_y, 7, 12))
        pygame.draw.ellipse(screen, RED, (sx - 10, y - 18 + offset_y, 20, 12))
        pygame.draw.circle(screen, WHITE, (sx - 4, y - 13 + offset_y), 2)
        pygame.draw.circle(screen, WHITE, (sx + 4, y - 14 + offset_y), 2)

    def draw_hud(self):
        pygame.draw.rect(screen, (15, 20, 18), (0, 0, WIDTH, 38))
        label = FONT.render(f"Lives: {self.lives}   Score: {self.score}", True, WHITE)
        screen.blit(label, (16, 8))
        hint = SMALL_FONT.render("Arrows / WASD move   SPACE/W jump", True, (191, 201, 183))
        screen.blit(hint, (WIDTH - hint.get_width() - 16, 10))

    def draw(self):
        offset_y = random.randint(-self.shake // 2, self.shake // 2) if self.shake else 0
        self.draw_background(offset_y)
        pygame.draw.rect(screen, (25, 32, 30), (0, 0, WIDTH, 58))
        for plat in PLATFORMS:
            self.draw_platform(plat, offset_y)
        for spike in self.stalactites:
            spike.draw(screen, self.camera_x)
        for m in self.mushrooms:
            if m[2]:
                self.draw_mushroom(m[0], m[1], offset_y)
        for spider in self.spiders:
            spider.draw(screen, self.camera_x)
        door_x = int(3410 - self.camera_x)
        pygame.draw.rect(screen, (76, 45, 27), (door_x, 333, 48, 62))
        pygame.draw.rect(screen, (183, 139, 66), (door_x + 7, 340, 34, 55), 3)
        pygame.draw.circle(screen, (241, 205, 96), (door_x + 35, 369), 3)
        self.player.draw(screen, self.camera_x)
        self.draw_hud()

        if self.state == "title":
            self.overlay("FREE YOUR MIND", "WALTER'S CAVE RUN", "Press ENTER to start - Arrow keys move - SPACE jumps")
        elif self.state == "gameover":
            self.overlay("GAME OVER", f"Final score: {self.score}", "Press ENTER to try again")
        elif self.state == "win":
            self.overlay("YOU MADE IT!", f"Cave cleared - Score: {self.score}", "Press ENTER to play again")
        pygame.display.flip()

    def overlay(self, title, subtitle, prompt):
        # Draws the dark title / game-over / win screen on top of the game.
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 175))
        screen.blit(shade, (0, 0))
        title_surf = BIG_FONT.render(title, True, (235, 227, 193))
        sub_surf = FONT.render(subtitle, True, (119, 190, 116))
        prompt_surf = SMALL_FONT.render(prompt, True, WHITE)
        screen.blit(title_surf, title_surf.get_rect(center=(WIDTH // 2, 190)))
        screen.blit(sub_surf, sub_surf.get_rect(center=(WIDTH // 2, 250)))
        screen.blit(prompt_surf, prompt_surf.get_rect(center=(WIDTH // 2, 305)))


async def main():
    # async main loop: lets the same game run in Terminal and in a web browser (pygbag).
    game = Game()
    running = True
    while running:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE and sys.platform != "emscripten":  # no quitting in a browser
                    running = False
                if event.key == pygame.K_RETURN:
                    if game.state in ("title", "gameover", "win"):
                        game.reset()
                        game.state = "playing"
        if game.state == "playing":
            game.update()
        game.draw()
        await asyncio.sleep(0)  # hands control back to the browser once per frame (required by pygbag)
    pygame.quit()


asyncio.run(main())